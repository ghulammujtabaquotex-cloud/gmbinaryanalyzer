import React, { useState, useEffect } from 'react';
import { ChartHeader } from './components/ChartHeader';
import { TradingViewChart } from './components/TradingViewChart';
import { SignalPanel } from './components/SignalPanel';
import { NotificationPopup, AlertData } from './components/NotificationPopup';
import { useMarketData } from './hooks/useMarketData';
import { useSupabaseSync } from './hooks/useSupabaseSync';
import { useTradeManager } from './hooks/useTradeManager';
import { saveNewSignal } from './services/tradeService';
import { API_CONFIG, SUPABASE_CONFIG, AVAILABLE_SYMBOLS } from './constants';
import { AlertCircle, Send, RefreshCw, ExternalLink, Activity, ShieldCheck, Globe, ShieldAlert } from 'lucide-react';

export const App: React.FC = () => {
  // State for the currently selected symbol, defaulting to the first one
  const [activeSymbol, setActiveSymbol] = useState(AVAILABLE_SYMBOLS[0].id);
  const [activeAlert, setActiveAlert] = useState<AlertData | null>(null);

  const { candles, currentCandle, connectionStatus, isLoading, refetch, dataError } = useMarketData(activeSymbol);
  
  // Sync logic running "in background"
  useSupabaseSync(currentCandle, activeSymbol);

  // Function to save signal to DB
  const persistSignal = async (symbol: string, type: 'CALL' | 'PUT', timeStr: string) => {
      await saveNewSignal({
          symbol: symbol,
          signal_type: type,
          confidence: 80, 
          entry_time: Math.floor(Date.now() / 1000),
          outcome: 'PENDING'
      });
  };

  // Handler for Auto-Analysis (Background)
  const handleSignalFound = (type: 'CALL' | 'PUT', entryTime: string) => {
      persistSignal(activeSymbol, type, entryTime);
  };
  
  // Handler for SignalPanel (AUTO SCANS)
  const handleSignalPanelFound = (
      symbol: string, 
      type: 'CALL' | 'PUT', 
      entryTime: string, 
      title?: string, 
      variant?: 'default' | 'warning'
    ) => {
      setActiveAlert({
          symbol: symbol,
          type: type,
          time: new Date().toLocaleTimeString(),
          price: 0, 
          entryTime: entryTime,
          title: title,
          variant: variant
      });
      if (variant !== 'warning') {
          persistSignal(symbol, type, entryTime);
      }
  };

  useTradeManager(candles, currentCandle, activeSymbol, handleSignalFound);

  const isSupabaseConfigured = !!(SUPABASE_CONFIG.URL && SUPABASE_CONFIG.KEY);

  // Basic Security
  useEffect(() => {
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
      return false;
    };
    document.addEventListener('contextmenu', handleContextMenu);
    return () => document.removeEventListener('contextmenu', handleContextMenu);
  }, []);

  const renderContent = () => {
    // 1. Critical Error: Fake Data
    if (dataError) {
        return (
            <div className="flex items-center justify-center h-full bg-[#131722] relative overflow-hidden">
                <div className="absolute inset-0 bg-red-500/5 animate-pulse z-0"></div>
                <div className="z-10 flex flex-col items-center gap-6 p-8 border-2 border-red-500/50 rounded-2xl bg-[#0e1118] shadow-[0_0_50px_rgba(239,83,80,0.2)] max-w-md text-center">
                    <ShieldAlert className="w-20 h-20 text-red-500 animate-bounce" />
                    <div>
                        <h1 className="text-3xl font-black text-red-500 tracking-widest uppercase mb-2">FAKE DATA EXPOSED</h1>
                        <p className="text-gray-400 text-sm leading-relaxed">
                            Security protocols have detected manipulated or significant latency in the market data stream.
                            <br/><br/>
                            <span className="text-red-400 font-bold">Risk Protection Active:</span> Charts are disabled to prevent false signals.
                        </p>
                    </div>
                    <button 
                        onClick={() => refetch()} 
                        className="mt-4 px-6 py-3 bg-red-600 hover:bg-red-500 text-white font-bold rounded shadow-lg transition-colors flex items-center gap-2"
                    >
                        <RefreshCw className="w-4 h-4" />
                        RECONNECT SECURELY
                    </button>
                </div>
            </div>
        );
    }

    const displaySymbol = AVAILABLE_SYMBOLS.find(s => s.id === activeSymbol)?.name || 
                          activeSymbol.replace('_otc', ' (OTC)').replace('-OTCq', ' (OTC)');

    if (isLoading) {
      return (
        <div className="flex items-center justify-center h-full">
            <div className="flex flex-col items-center gap-4">
                <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                <span className="text-gray-400 text-sm">Loading market data for {displaySymbol}...</span>
            </div>
        </div>
      );
    }

    if (candles.length === 0 && !currentCandle) {
        return (
            <div className="flex items-center justify-center h-full">
                <div className="flex flex-col items-center gap-4 text-red-400 text-center px-4">
                    <AlertCircle className="w-12 h-12" />
                    <span className="text-lg font-medium">No Data Available</span>
                    <span className="text-sm text-gray-500 max-w-xs">The connection was closed or the API is unreachable.</span>
                    <button 
                        onClick={() => refetch()} 
                        className="mt-2 flex items-center gap-2 px-4 py-2 bg-[#2a2e39] hover:bg-[#363a45] text-white rounded text-sm transition-colors border border-gray-700"
                    >
                        <RefreshCw className="w-4 h-4" />
                        Reload
                    </button>
                </div>
            </div>
        );
    }

    return (
        <TradingViewChart 
          data={candles} 
          currentCandle={currentCandle}
          config={{
              symbol: activeSymbol,
              interval: API_CONFIG.DEFAULT_INTERVAL,
              limit: API_CONFIG.DEFAULT_LIMIT,
              timezoneOffset: API_CONFIG.TIMEZONE_OFFSET_HOURS
          }}
        />
    );
  };

  return (
    <div className="flex flex-col h-[100dvh] bg-[#131722] text-white overflow-hidden select-none">
      <ChartHeader 
        price={currentCandle?.close} 
        status={dataError ? 'error' : connectionStatus}
        isSupabaseEnabled={isSupabaseConfigured}
        activeSymbol={activeSymbol}
        onSymbolChange={setActiveSymbol}
        onRefresh={refetch}
      />
      
      <main className="flex-1 w-full h-full relative">
        {renderContent()}
      </main>

      {!dataError && (
          <>
            <NotificationPopup 
                alert={activeAlert} 
                onClose={() => setActiveAlert(null)} 
            />

            <SignalPanel 
                activeSymbol={activeSymbol}
                setActiveSymbol={setActiveSymbol}
                onSignalFound={handleSignalPanelFound}
                candles={candles}
                isLoading={isLoading}
            />
          </>
      )}

      <footer className="h-7 bg-[#0e1118] border-t border-[#2a2e39] flex items-center justify-between px-3 z-40 shrink-0 text-[10px] font-sans">
        <div className="flex items-center gap-4">
            <a 
                href="https://chat.whatsapp.com/LqDeKcUo89c3Hu5CWjaAM9" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-2 group hover:text-white text-[#8b919d] transition-colors"
            >
                <Globe className="w-3 h-3 group-hover:text-green-400 transition-colors" />
                <span className="font-semibold tracking-wide">GM COMMUNITY</span>
                <span className="relative flex h-1.5 w-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-green-500"></span>
                </span>
            </a>
            <div className="h-3 w-[1px] bg-[#2a2e39]"></div>
            <div className="flex items-center gap-1.5 text-[#8b919d]">
                <ShieldCheck className="w-3 h-3 text-blue-500" />
                <span>SECURE CONNECTION</span>
            </div>
        </div>
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
             <a 
                href="https://broker-qx.pro/sign-up/?lid=1416949" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="flex items-center gap-2 text-[#6d717a] hover:text-white transition-colors"
            >
                <span>BROKER:</span>
                <span className="font-bold text-[#00c853] flex items-center gap-1">
                    QUOTEX <ExternalLink className="w-2.5 h-2.5" />
                </span>
            </a>
        </div>
        <div className="flex items-center gap-4">
             <div className="flex items-center gap-1.5 text-[#8b919d]">
                 <Activity className="w-3 h-3 text-orange-400" />
                 <span>LATENCY: 24ms</span>
             </div>
             <div className="h-3 w-[1px] bg-[#2a2e39]"></div>
            <a 
                href="https://t.me/binarysupport" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 group hover:text-white text-[#8b919d] transition-colors"
            >
                <span className="font-semibold">@binarysupport</span>
                <Send className="w-3 h-3 group-hover:text-blue-500 transition-colors" />
            </a>
        </div>
      </footer>
    </div>
  );
};