import { analyzeMarket } from './technicalAnalysis';
import { OHLC, SignalResponse } from '../types';
import { supabase } from '../lib/supabaseClient';

/**
 * BACKEND PROXY
 * This simulates a backend controller for the /signal endpoint.
 * It handles validation, logic execution, and database syncing.
 */

let lastRequestTime = 0;
const RATE_LIMIT_MS = 2000; // 2 seconds between requests
let isSignalsTableMissing = false;

export const getSignalEndpoint = async (candles: OHLC[]): Promise<SignalResponse> => {
  // 1. Backend Validation (Rate Limiting)
  const now = Date.now();
  if (now - lastRequestTime < RATE_LIMIT_MS) {
    // Fail silently or throw, UI handles errors gracefully usually
    // Returning a dummy response or throwing is fine. 
    // For smoothness, we can just throw and let the caller debounce.
    throw new Error(`Rate limit exceeded. Please wait ${(RATE_LIMIT_MS - (now - lastRequestTime)) / 1000}s.`);
  }
  lastRequestTime = now;

  // 2. RULES REMOVED: No Time Window Check (31s-59s removed)

  // 3. Execute Backend Logic (Analysis)
  const result = analyzeMarket(candles);

  // 4. Sync to Supabase (Disabled mostly in this version, but logic kept for reference)
  if (supabase && !isSignalsTableMissing) {
    try {
      const { error } = await supabase.from('signals').insert({
        symbol: 'NZDUSD-OTCq', 
        signal: result.signal,
        confidence: result.confidence,
        reason: result.reason,
        created_at: new Date().toISOString(),
        indicators: result.indicators 
      });
      
      if (error) {
        const errMsg = error.message.toLowerCase();
        const isMissingTable = 
            error.code === '42P01' || 
            errMsg.includes('could not find the table') || 
            errMsg.includes('relation') && errMsg.includes('does not exist');

        if (isMissingTable) {
            console.warn("Supabase Sync Paused: Table 'signals' not found.");
            isSignalsTableMissing = true;
        } 
      }
    } catch (err) {
      console.warn('Supabase Signal Sync Exception:', err);
    }
  }

  return result;
};
