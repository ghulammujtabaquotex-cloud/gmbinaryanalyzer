import { supabase } from '../lib/supabaseClient';
import { TradeSignal } from '../types';

export const fetchSignalHistory = async (symbol: string): Promise<TradeSignal[]> => {
  if (!supabase) return [];
  try {
      const { data, error } = await supabase
          .from('signals')
          .select('*')
          .eq('symbol', symbol)
          .order('entry_time', { ascending: false })
          .limit(20);

      if (error) throw error;
      return data || [];
  } catch (e) {
      console.warn("Failed to fetch history", e);
      return [];
  }
};

export const saveNewSignal = async (signal: Omit<TradeSignal, 'id'>): Promise<TradeSignal | null> => {
  if (!supabase) return null;
  try {
      const { data, error } = await supabase
          .from('signals')
          .insert(signal)
          .select()
          .single();

      if (error) {
        console.warn("Failed to save signal:", error.message);
        return null;
      }
      return data;
  } catch (e) {
      console.warn("Save Signal Exception", e);
      return null;
  }
};

export const updateSignalOutcome = async (id: number, outcome: string) => {
    if (!supabase) return;
    try {
        await supabase
            .from('signals')
            .update({ outcome })
            .eq('id', id);
    } catch (e) {
        // ignore
    }
};

export const processTradeOutcomes = async (
    signals: TradeSignal[], 
    candles: any[]
): Promise<{ updatedSignals: TradeSignal[], hasChanges: boolean }> => {
    // Basic logic to check if a pending signal has a result
    // Not strictly needed for the Notification-only flow, but kept for future
    return { updatedSignals: signals, hasChanges: false };
};