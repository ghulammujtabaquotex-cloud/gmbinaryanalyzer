

// ---------------------------------------------------------
// SECURITY CONFIGURATION
// ---------------------------------------------------------

export const API_CONFIG = {
  // New API Endpoint provided
  HISTORY_URL: "https://mrbeaxt.site/Qx/Qx.php",
  // TICK_STREAM_URL is not provided for the new API, so we rely on polling the history endpoint
  get TICK_STREAM_URL() { return ""; }, 
  DEFAULT_SYMBOL: 'Nzdusd_otc', 
  DEFAULT_INTERVAL: '1m',
  DEFAULT_LIMIT: 500,
  // User Requirement: API is UTC+6, Target is UTC+5. 
  // Difference is -1 Hour.
  TIMEZONE_OFFSET_HOURS: -1, 
};

export const AVAILABLE_SYMBOLS = [
  // --- OTC PAIRS ---
  { id: 'AUDNZD_otc', name: 'AUD/NZD (OTC)' },
  { id: 'Cadchf_otc', name: 'CAD/CHF (OTC)' },
  { id: 'Eurnzd_otc', name: 'EUR/NZD (OTC)' },
  { id: 'GBPNZD_otc', name: 'GBP/NZD (OTC)' },
  { id: 'Nzdcad_otc', name: 'NZD/CAD (OTC)' },
  { id: 'NZDCHF_otc', name: 'NZD/CHF (OTC)' },
  { id: 'Nzdjpy_otc', name: 'NZD/JPY (OTC)' },
  { id: 'Nzdusd_otc', name: 'NZD/USD (OTC)' },
  
  // --- MAJORS (NON-OTC) ---
  { id: 'EURUSD', name: 'EUR/USD' },

  // --- CRYPTO (OTC) ---
  { id: 'BCHUSD_otc', name: 'BCH/USD (OTC)' },
  { id: 'BTCUSD_otc', name: 'BTC/USD (OTC)' },

  // --- COMMODITIES (OTC) ---
  { id: 'XAUUSD_otc', name: 'Gold (OTC)' },
  { id: 'AXP_otc', name: 'American Express (OTC)' }, // Listed as AXP in user list

  // --- EMERGING & EXOTIC (OTC) ---
  { id: 'BRLUSD_otc', name: 'BRL/USD (OTC)' },
  { id: 'Usdars_otc', name: 'USD/ARS (OTC)' },
  { id: 'Usdbdt_otc', name: 'USD/BDT (OTC)' },
  { id: 'Usdcop_otc', name: 'USD/COP (OTC)' },
  { id: 'Usddzd_otc', name: 'USD/DZD (OTC)' },
  { id: 'Usdegp_otc', name: 'USD/EGP (OTC)' },
  { id: 'Usdidr_otc', name: 'USD/IDR (OTC)' },
  { id: 'Usdinr_otc', name: 'USD/INR (OTC)' },
  { id: 'Usdngn_otc', name: 'USD/NGN (OTC)' },
  { id: 'Usdphp_otc', name: 'USD/PHP (OTC)' },
  { id: 'Usdpkr_otc', name: 'USD/PKR (OTC)' },
  { id: 'Usdtry_otc', name: 'USD/TRY (OTC)' },
];

export const CHART_COLORS = {
  BACKGROUND: '#131722',
  GRID: 'rgba(42, 46, 57, 0.5)',
  TEXT: '#d1d4dc',
  UP_COLOR: '#26a69a',
  DOWN_COLOR: '#ef5350',
  BORDER_VISIBLE: false,
  WICK_UP: '#26a69a',
  WICK_DOWN: '#ef5350',
};

// ---------------------------------------------------------
// SUPABASE CONFIGURATION
// Paste your Supabase credentials below inside the quotes ''
// ---------------------------------------------------------
export const SUPABASE_CONFIG = {
  URL: 'https://kmntltoaunnaapesbdem.supabase.co',
  KEY: 'sb_publishable_6vyq7JRBAhscN6fIlUZKXw_-4ttr-r5',
  TABLE_NAME: 'candles'
};