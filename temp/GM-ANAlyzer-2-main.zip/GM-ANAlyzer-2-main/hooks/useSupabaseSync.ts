
import { useEffect, useRef } from 'react';
import { supabase } from '../lib/supabaseClient';
import { OHLC, DatabaseCandle } from '../types';
import { API_CONFIG, SUPABASE_CONFIG } from '../constants';

export const useSupabaseSync = (currentCandle: OHLC | null, symbol: string) => {
  // Ref to track if sync is permanently disabled due to missing tables or network errors
  const isSyncDisabled = useRef(false);

  useEffect(() => {
    if (!supabase || !currentCandle || isSyncDisabled.current) return;

    const syncToDb = async () => {
      try {
        const dbRecord: DatabaseCandle = {
          symbol: symbol,
          time: new Date((currentCandle.time - (API_CONFIG.TIMEZONE_OFFSET_HOURS * 3600)) * 1000).toISOString(), // Convert back to UTC ISO for storage
          open: currentCandle.open,
          high: currentCandle.high,
          low: currentCandle.low,
          close: currentCandle.close,
        };

        // Upsert based on time and symbol
        const { error } = await supabase
          .from(SUPABASE_CONFIG.TABLE_NAME)
          .upsert(dbRecord, { onConflict: 'symbol,time' });

        if (error) {
          const errMsg = error.message ? error.message.toLowerCase() : '';
          
          // 1. Handle Network/CORS/Fetch Errors
          if (errMsg.includes('failed to fetch') || errMsg.includes('network error')) {
              if (!isSyncDisabled.current) {
                  console.warn(`Supabase Sync Disabled: Network error or invalid configuration. (${error.message})`);
                  isSyncDisabled.current = true;
              }
              return;
          }

          // 2. Check for various forms of "table not found" errors (PGRST204, 42P01)
          const isMissingTable = 
            error.code === '42P01' || 
            errMsg.includes('could not find the table') || 
            (errMsg.includes('relation') && errMsg.includes('does not exist'));

          if (isMissingTable) {
             if (!isSyncDisabled.current) {
                 console.warn(`Supabase Sync Paused: Table '${SUPABASE_CONFIG.TABLE_NAME}' not found. Please run the SQL initialization script in your Supabase dashboard.`);
                 isSyncDisabled.current = true;
             }
          } else {
             // Only log unexpected errors
             console.error('Supabase Sync Error:', error.message);
          }
        }
      } catch (err: any) {
        // Catch-all for non-supabase-client errors (like severe network failures)
        if (!isSyncDisabled.current) {
            const msg = err instanceof Error ? err.message : String(err);
            if (msg.toLowerCase().includes('failed to fetch')) {
                 console.warn('Supabase Sync Disabled: Connection failed.');
                 isSyncDisabled.current = true;
            } else {
                 console.error('Supabase Sync Exception:', err);
            }
        }
      }
    };

    syncToDb();

  }, [currentCandle, symbol]);
};
