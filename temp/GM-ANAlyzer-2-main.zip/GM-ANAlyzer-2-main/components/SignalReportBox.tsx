import React from 'react';
import { TradeSignal } from '../types';
import { Trophy, Clock } from 'lucide-react';

interface SignalReportBoxProps {
    signals: TradeSignal[];
}

export const SignalReportBox: React.FC<SignalReportBoxProps> = ({ signals }) => {
    // Calculate Stats
    const total = signals.filter(s => s.outcome !== 'PENDING' && s.outcome !== 'MTG_PENDING').length;
    const wins = signals.filter(s => s.outcome === 'WIN' || s.outcome === 'MTG_WIN').length;
    const losses = signals.filter(s => s.outcome === 'LOSS').length;
    const winRate = total > 0 ? Math.round((wins / total) * 100) : 0;

    // Last 5 signals for table
    const recentSignals = [...signals].reverse().slice(0, 5);

    return (
        <div className="absolute bottom-20 left-4 z-20 bg-[#131722]/90 backdrop-blur-md border border-gray-700 rounded shadow-xl w-64 overflow-hidden pointer-events-none select-none">
            {/* Header */}
            <div className="bg-[#1e222d] p-2 border-b border-gray-700 flex justify-between items-center">
                <h3 className="text-xs font-bold text-gray-200 flex items-center gap-1">
                    <Trophy className="w-3 h-3 text-yellow-500" />
                    SIGNAL REPORT
                </h3>
                <span className={`text-xs font-bold ${winRate >= 50 ? 'text-green-400' : 'text-red-400'}`}>
                    WR: {winRate}%
                </span>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-3 gap-1 p-2 border-b border-gray-700/50">
                <div className="text-center">
                    <div className="text-[10px] text-gray-500">Wins</div>
                    <div className="text-sm font-bold text-green-400">{wins}</div>
                </div>
                <div className="text-center">
                    <div className="text-[10px] text-gray-500">Loss</div>
                    <div className="text-sm font-bold text-red-400">{losses}</div>
                </div>
                <div className="text-center">
                    <div className="text-[10px] text-gray-500">Total</div>
                    <div className="text-sm font-bold text-blue-400">{total}</div>
                </div>
            </div>

            {/* Table */}
            <div className="p-1">
                <table className="w-full text-[10px]">
                    <thead>
                        <tr className="text-gray-500 border-b border-gray-800">
                            <th className="text-left p-1">Time</th>
                            <th className="text-left p-1">Type</th>
                            <th className="text-right p-1">Result</th>
                        </tr>
                    </thead>
                    <tbody>
                        {recentSignals.map((sig) => (
                            <tr key={sig.id} className="border-b border-gray-800/50 last:border-0">
                                <td className="p-1 text-gray-400">
                                    {new Date(sig.entry_time * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}
                                </td>
                                <td className={`p-1 font-bold ${sig.signal_type === 'CALL' ? 'text-green-500' : 'text-red-500'}`}>
                                    {sig.signal_type}
                                </td>
                                <td className="p-1 text-right">
                                    {sig.outcome === 'WIN' && <span className="bg-green-500/20 text-green-400 px-1 rounded">WIN</span>}
                                    {sig.outcome === 'MTG_WIN' && <span className="bg-blue-500/20 text-blue-400 px-1 rounded">MTG</span>}
                                    {sig.outcome === 'LOSS' && <span className="bg-red-500/20 text-red-400 px-1 rounded">LOSS</span>}
                                    {(sig.outcome === 'PENDING' || sig.outcome === 'MTG_PENDING') && (
                                        <Clock className="w-3 h-3 text-yellow-500 inline ml-auto" />
                                    )}
                                </td>
                            </tr>
                        ))}
                        {recentSignals.length === 0 && (
                            <tr>
                                <td colSpan={3} className="text-center text-gray-600 p-2">No signals yet</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};